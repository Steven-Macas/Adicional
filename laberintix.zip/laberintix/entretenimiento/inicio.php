<?php

	SESSION_START();

	//Array donde se guarda las preguntas
	$preguntasEntretenimiento = array('¿Quién es la mascota de SEGA?', '¿A qué película de Disney pertenece la canción "Un mundo ideal"?', '¿A quién se considera el Rey del Pop?', '¿Cómo se llama el pájaro símbolo de los Juegos del Hambre?', '¿Quién canta " Vivir mi vida"?', '¿Qué Beatle fue asesinado por un fan?', '¿De qué distrito es Katniss de Los juegos del hambre?', '¿Rowan Atkinson es famoso por el personaje llamado...', '¿Cómo se llama el payaso de "Los Simpson"?', '¿Cuándo comenzó a emitirse Gran Hermano en España ?', '¿Quién protagonizo la pelicula "Descubriendo nunca jamás"?', '¿Qué cantante hizo una aparición en el medio tiempo del Superbowl 2014?', '¿Quién se hizo famoso,gracias a su frase "que hay de nuevo viejo"?', '¿Cuál es la nacionalidad de la cantante Shakira?', '¿Cuál es el nombre real de Lady Gaga?', '¿De qué color era Clifford, el perro gigante?', '¿Cuál es el nombre de la canción de la película "Titanic"?', '¿Quién resulta ser el príncipe mestizo en la sexta película de Harry Potter?', '¿Cuántas categorías tiene el juego "Preguntados"?', '¿En qué año se estrenó la película de Disney "Pinocho"?');

	$_SESSION['respuestasEntretenimiento'] = array( array('Sonic', 'Mario', 'Pac Man', 'Ryu'), array('Mulán', 'Pocahontas', 'Aladdín', 'Hércules'), array('Justin Bieber', 'Michael Jackson', 'Bad Bunny', 'Zac Efron'), array('Lechuza', 'Sinsajo', 'Gale', 'Llamas '), array('Pitbull', 'Jay Z', 'Chris Brown', 'Marc Anthony'),  array('George Harrison', 'Ringo Star', 'Ninguno ', 'Jonh Lennon'), array('Distrito 3', 'Distrito 8', 'Distrito 12', 'Distrito 11'), array('Benjamin Button', 'Mr.Bean', 'El sombrerero loco', 'Link'), array('Krusty', 'Kristy', 'Kris', 'Kroger'), array('1998', '2000', '2001', '2003'), array('Brad Pitt', 'Leonardo Dicaprio', 'Paul Walker ', 'Johnny Deep'), array('Justin Bieber', 'Bruno Mars', 'Rihanna', 'Luciano Pavarotti'), array('Bugs bunny', 'Piolin', 'El Correcaminos', 'El pato Lucas'), array('Venezolana', 'Ecuatoriana', 'Colombiana', 'Peruana'), array('Robyn Fenty', 'Stefani Germanotta', 'Onika Maraj', 'Beth Moore'), array('Verde', 'Azul', 'Rojo', 'Amarillo'), array('Bad Romance', "Livin' on a prayer", 'Killer queen', 'My heart will go on'), array('Lord Voldemort', 'Albus Dumbuldore', 'Severus Snape', 'Sirius Black'), array('4', '6', '5', '7'), array('1940', '1950', '1952', '1946'));

	//Comprobar si el array de las preguntas está vacío o no.
	if ($_SESSION['vacioEntretenimientos']=='si') {
		$_SESSION['preguntasEntretenimiento']=$preguntasEntretenimiento;
		$_SESSION['vacioEntretenimientos']='no';
	}

	$sala= mt_rand(1,10);
	$_SESSION['sala']=$sala;
	header('Location: sala' . $sala . '.php');

?>