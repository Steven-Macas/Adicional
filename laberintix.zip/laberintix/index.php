<?php

SESSION_START();

session_destroy();
unset($_SESSION);
?>

<!DOCTYPE html>
<html lang="es">
   <head>
      <title>Laberinto</title>
      <meta charset="UTF-8"/>
      <meta name="author" content="Roberth Steven Macas Ordóñez"/>
      <meta name="keywords" content="Server steven owncloud"/>
      <meta name="description" content="Este es un servidor que se ha realizado para el proyecto integrado de ASIR, IES Zaidín Vergeles"/>
      <link rel="stylesheet" type="text/css" href="index.css"/>
      <link rel="icon" href="./imagenes/logo.png"/>
   </head>
   <body>
     <h1>Bienvenido al Laberinto Cultural</h1>
      <form action="introduccion.php" method="post">
      <fieldset>
        <legend>JUGADOR</legend>
            <label for="usuario">Nombre del jugador</label>
            <input type="text" id="usuario" name="nombre" required/><br/>
        </fieldset>
        <input type="submit" value="Jugar" id="inpEnviar" />
      </form>
   </body>
</html>