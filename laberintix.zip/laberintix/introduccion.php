<?php

SESSION_START();

?>

<!DOCTYPE html>
<html lang="es">
   <head>
      <title>Laberentix</title>
      <meta charset="UTF-8"/>
      <link rel="stylesheet" type="text/css" href="index.css"/>
      <link rel="icon" href="./imagenes/logo.png"/>
   </head>
   <body>
<?php
if(isset($_POST['nombre'])){
$_SESSION['nombre']=$_POST['nombre'];
}
echo "<h1>Bienvenido " . $_SESSION['nombre'] . "</h1>";
echo "<h3 id='introduccionLaberentix'>En este juego tienes que recorrer todas las salas y responder a 10 preguntas para poder entrar a la sala final, si fallas vuelves a empezar perdiendo todos los puntos y si aciertas ganas la insignia de esa categoria y desbloqueas al personaje. El objetivo es conseguir las insignias de cada tema y desbloquear a todos los personajes. </h3>";
echo '<a href="categorias.php"><button id="inpEnviar2">Empezar</button></a>';

$_SESSION['PUERTA1']="cerrada";
$_SESSION['INSIGNIA1']='fallo';

$_SESSION['PUERTA2']="cerrada";
$_SESSION['INSIGNIA2']='fallo';


$_SESSION['PUERTA3']="cerrada";
$_SESSION['INSIGNIA3']='fallo';

$_SESSION['PUERTA4']="cerrada";
$_SESSION['INSIGNIA4']='fallo';

$_SESSION['PUERTA5']="cerrada";
$_SESSION['INSIGNIA5']='fallo';

$_SESSION['totalAcertadas']=0;
?>
   </body>
</html>