<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Laberentix</title>
	<link rel="stylesheet" type="text/css" href="index.css"/>
    <link rel="icon" href="./imagenes/logo.png"/>
	<style>
        	img{
            	display: block;
            }
        	div{
            	display: inline-block;
                margin: 20px;
            }
        </style>
</head>
<body id="gameOver">
	<h1 id='eleccionPuerta'>¡Enhorabuena! Has conseguido todas las insignia y desbloqueado todos los personajes.</h1>
	<div class='categoriasAnimacion2'>
		<h4>Deportes</h4>
		<img src='./imagenes/insignia1.png' alt='Insignia Nº1' class='insignias'/>
	</div>

	<div class='categoriasAnimacion3'>
		<h4>Historia</h4>
		<img src='./imagenes/insignia2.png' alt='Insignia Nº2' class='insignias'/>
	</div>

	<div class='categoriasAnimacion4'>
		<h4>Ciencia</h4>
		<img src='./imagenes/insignia3.png' alt='Insignia Nº3' class='insignias'/>
	</div>

	<div class='categoriasAnimacion5'>
		<h4>Geografía</h4>
		<img src='./imagenes/insignia4.png' alt='Insignia Nº4' class='insignias'/>
	</div>

	<div class='categoriasAnimacion6'>
		<h4>Entretenimiento</h4>
		<img src='./imagenes/insignia5.png' alt='Insignia Nº5' class='insignias'/>
	</div>
	<a href="./../"><button id="inpEnviar" style="margin-left: 50%;">Volver al menú</button></a>
</body>
</html>