<?php

	SESSION_START();

	//Array donde se guarda las 
	$preguntasDeporte = array('¿Cuándo se celebró el primer mundial de fútbol?', '¿Qué selección de fútbol ha ganado más Mundiales?', '¿Quién es el máximo goleador actual del FC Barcelona?', '¿Qué revista concede el Balón de Oro?', '¿Qué selección ganó la Copa Mundial de Fútbol en Sudafrica 2010?', 'Qué equipo ha ganado más Champions League de la historia?', '¿Quién se considera el mejor jugador de baloncesto de todos los tiempos?', '¿Cuántos anillos de la NBA ha conseguido Shaquille O’Neal?', '¿Qué tipo de competición es el Giro de Italia?', '¿Quién ganó cuatro mundiales consecutivos de Fórmula 1?', '¿Cuántos Grand Slam tiene Roger Federer?', '¿Qué entrenador argentino es conocido como "El Cholo"?', '¿Quién es conocido como “O Rei”?', '¿Qué equipo de fútbol juega en el estadio El Molinón?', '¿Cuánto dura un partido de fútbol?', '¿Cuál es el apodo del Leicester City?', '¿Cuánto dura la prórroga en un partido de fútbol?', '¿Qué número llevaba a la espalda Raúl González del Real Madrid?', '¿Qué equipos componen el derbi sevillano?', '¿En qué club italiano jugó Diego Maradona?');

	$_SESSION['respuestasDeporte'] = array( array('El 13 de julio de 1930 en Uruguay', 'El 30 de junio de 1928 en Brasil', 'El 10 de agosto de 1933 en Francia', 'El 25 de junio de 1930 en Italia'), array('Francia', 'Brasil', 'Holanda', 'Italia'), array('Neymar Jr', 'Luis Suares', 'Messi', 'Andrés Iniesta'), array('La revista BBC', 'La revista France Football', 'La revista Grazia', 'La revista Cosmopolitan'), array('Holanda', 'Alemania', 'España', 'Argentina'),  array('Real Madrid', 'Liverpool', 'Bayern de Munich', 'FC Barcelona'), array('Lebron James', 'Stephen Curry', 'Michael Jordan', 'Kobe Bryant'), array('4 anillos', '3 anillos', '5 anillos', '1 anillo'), array('Ciclismo', 'Natación', 'Fútbol', 'Baloncesto'), array('Lewis Hamilton', 'Max Verstappen', 'Fernando Alonso', 'Sebastián Vettel'), array('18 títulos individuales', '13 títulos individuales', '20 títulos individuales', '24 títulos individuales'), array('Luis Enrique', 'Pep Guardiola', 'Diego Simeone', 'Zinedine Zidane'), array('Cristiano Ronaldo', 'Ronaldinho', 'Vinicius Jr', 'Pele'), array('Real Sporting de Gijón', 'FC Barcelona', 'Real Madrid', 'Sevilla FC'), array('90 minutos', '45 minutos', '105 minutos', '120 minutos'), array('La Roja', 'Los zorros', 'La Tricolor', 'Los Murcielagos'), array('30 minutos', '15 minutos', '20 minutos', '45 minutos'), array('Número 10', 'Número 7', 'Número 11', 'Número 21'), array('Sevilla vs Betis', 'Sevilla vs Real Madrid', 'Sevilla vs Espanyol', 'Sevilla vs Barcelona'), array('Juventus', 'Nápoli', 'Atalanta', 'Roma'));

	//Comprobar si el array de las preguntas está vacío o no.
	if ($_SESSION['vacioDeportes']=='si') {
		$_SESSION['preguntasDeporte']=$preguntasDeporte;
		$_SESSION['vacioDeportes']='no';
	}

	$sala= mt_rand(1,10);
	$_SESSION['sala']=$sala;
	header('Location: sala' . $sala . '.php');

?>