<?php
	session_start();

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Laberentix</title><title>Laberentix</title><link rel="stylesheet" type="text/css" href="index.css"/>
    <link rel="icon" href="./imagenes/logo.png"/>
    <title>Laberentix</title><link rel="stylesheet" type="text/css" href="index2.css"/>
    <link rel="icon" href="./imagenes/logo.png"/>
</head>
<body>
	<h1 id="sala">Sala 3</h1>
	<form action="resultado.php" method="post">
		<fieldset>
			<legend>Pregunta</legend>
			<?php
			//Hacemos que salga de forma aleatoria una pregunta del banco de preguntas que tenemos en el array
			$p=mt_rand(0,19);
			if(empty($_SESSION['preguntasHistoria'][$p])){
				while (empty($_SESSION['preguntasHistoria'][$p])) {
					$p=mt_rand(0,19);
				}
			}
			echo "<label>". $_SESSION['preguntasHistoria'][$p] . "<label><br/>";
			for ($i=0; $i <4 ; $i++) { 
				echo "<input type='radio' name='respuesta' value='" . $_SESSION['respuestasHistoria'][$p][$i] ."' id='" . $_SESSION['respuestasHistoria'][$p][$i] . "'/>";
				echo "<label for='" . $_SESSION['respuestasHistoria'][$p][$i] . "'>" . $_SESSION['respuestasHistoria'][$p][$i] . "</label></br>"; 
			}
			
			echo "</fieldset>";
			echo '<input type="submit" value="Comprobar" id="inpEnviar"/>';
			echo "</form>";
			//Comprobar si ha elegido una opcion
				if (isset($_SESSION['respondida'])) {
					if ($_SESSION['respondida']=='no') {
						echo "<h5>Por favor, selecciona una respuesta</h5>";
						$_SESSION['respondida']='si';
					}
				}

			//Guardamos la pregunta que ha salido para después comprobar si la ha acertado la quitamos del array de las preguntas
			$_SESSION['preguntaHistoria']=$p;

			//Si tiene suerte, puede que tenga la opción de salir y elegir otra categoría
			$aleatorioSalida=mt_rand(1,5);
			$aleatorioSalida2=mt_rand(1,5);
			if ($aleatorioSalida==$aleatorioSalida2) {
				echo "<div><h4>¡Vaya! Has encontrado la puerta oculta.</h4>";
				echo "<a href='./../categorias.php'><img src='./imagenes/puertaCerrda.png' alt='Puerta Salida'/></a></div>";
			}

			//Si tienen suerte, puede que tenga la opción de ir directamente a la pregunta final
			$aleatorioJefe=mt_rand(1,10);
			$aleatorioJefe2=mt_rand(1,10);
			if ($aleatorioJefe==$aleatorioJefe2) {
				echo "<div id='puertaJefe'><h4>¡Vaya! Has encontrado la puerta del jefe.</h4>";
				echo "<a href='jefeHistoria.php'><img src='./imagenes/puertaJefe.png' /></a></div>";
			}

				
			?>
	
</body>
</html>