<?php
	SESSION_START();
?>
<!DOCTYPE html>
<html lang="es">
	<head>
		<title>Historia</title>
		<meta charset="UTF-8"/>
		<link rel="stylesheet" type="text/css" href="index.css"/>
        <link rel="icon" href="./imagenes/logo.png"/>
	</head>
	<body>
		<section id="bienvenidoHistoria">
			<h1>Bienvenido al mundo de Laberentix</h1>
			<div id="parteMedio">
				<h2>Te encontrarás con todo tipo de preguntas sobre la historia</h2>
				<img src="./imagenes/laberinto2.png" alt="portada" id="portada" />
				<a href="inicio.php" id="empezar"><h3>A recordar</h3></a>
				<h3>ADVERTENCIA: Una vez que entres, solo hay tres formas de salir, tienes que acertar 10 preguntas o encontrar la puerta de la sala final o tienes que encontrar la puerta escondida que pocos la han encontrado.</h3>
			</div>
		</section>
		<?php
			$_SESSION['vacioHistorias']='si';
			$_SESSION['acertadas']=0;
		?>
	</body>
</html>