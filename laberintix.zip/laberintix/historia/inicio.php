<?php

	SESSION_START();

	//Array donde se guarda las preguntas
	$preguntasHistoria = array('¿Qué se celebra el 8 de Marzo?', '¿Dónde surgió la filosofía?', '¿Qué modelo de Estado se propugna en la Constitución española?', 'Los cuatro evangelistas de la Biblia son Mateo, Marcos, Lucas y...', '¿Quién gobernó Francia desde 1799 a 1815?', '¿Quién presidia España durante el fallido golpe de estado del 23 de Febrero de 1981?', '¿Qué imperio llegó a conquistar casí toda Europa?', '¿Quiénes fueron los Reyes Católicos?', '¿En qué año se instauró el sufragio femenino en España?', '¿Qué sobrenombre tenía Guillermo I de Inglaterra?', '¿En qué viaje Colón encontró a los Mayas?', '¿De dónde es originario el pan con aceite y azúcar?', '¿En qué país nació el rey Juan Carlos I?', '¿Cómo se llamaba el hermano de Napoleón Bonaparte?', '¿Dónde se encuentra actualmente la Dama de Elche?', '¿Cómo se llamaba el hijo bastardo de Carlos V?', '¿Qué título recibían los soberanos musulmanes en España?', '¿Qué Emperador Romano estuvo más años en el poder ?', '¿En qué siglo termina la Edad Media?', '¿Quién es el sucesor directo de Juan Carlos I?');

	$_SESSION['respuestasHistoria'] = array( array('El día del trabajo', 'El día del medio ambiente', 'El día de la mujer', 'El día del niño'), array('Grecia', 'España', 'Egipto', 'Japón'), array('Estado federal', 'Estado social y democrático de Derecho', 'Estado de Derecho', 'Estado liberal'), array('Antonio', 'Jésus', 'José', 'Juan'), array('Adam Smith', 'François Quesnay', 'Napoleón Bonaparte', 'Louis Bonaldgug'),  array('Adolfo Suárez', 'Leopoldo Calvo Sotelo', 'Felipe Gonzalez', 'Manual Fraga Iribarne'), array('Cartago', 'Romano', 'Espartano', 'Vikingo'), array('Juana I y Felipe I', 'Isabel I y Fernando II', 'Isabel II y Francisco de Asís', 'Isabel I y Fernando VII'), array('1921', '1951', '1971', '1931'), array('El Valiente', 'El Loco', 'El Conquistador', 'El Tirano'), array('Cuarto', 'Tercero', 'Segundo', 'Primero'), array('Castilla la Mancha', 'Valencia', 'Andalucía ', 'Cataluña'), array('España', 'Austria', 'Francia', 'Italia'), array('Pierre Bonaparte', 'Jose Bonaparte', 'Ernesto Bonaparte', 'Pita Bonaparte'), array('Elche', 'Madrid', 'Segovia', 'Barcelona'), array('Juan de Austria', 'Duque de Alba', 'Juan de Tordesillas', 'Marqués de Villena'), array('Rey', 'Jeque', 'Khaleesi', 'Califa'), array('Octavio Augusto', 'Vespasiano', 'Claudio', 'Adriano'), array('XIII', 'XIV', 'XV', 'XVI'), array('Leticia Ortiz', 'Felipe VI', 'Infanta Leonor', 'Infanta Sofía'));

	//Comprobar si el array de las preguntas está vacío o no.
	if ($_SESSION['vacioHistorias']=='si') {
		$_SESSION['preguntasHistoria']=$preguntasHistoria;
		$_SESSION['vacioHistorias']='no';
	}

	$sala= mt_rand(1,10);
	$_SESSION['sala']=$sala;
	header('Location: sala' . $sala . '.php');

?>