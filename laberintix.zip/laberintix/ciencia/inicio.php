<?php

	SESSION_START();

	//Array donde se guarda las preguntas
	$preguntasCiencia = array('¿Cuál de las sisguientes enfermedades ataca al higado?', '¿Cuál es la función principal del instestino grueso?', '¿Qué cambio de estado ocurre en la sublimación?', '¿Cuántas caras tiene un icosaedro?', '¿Con qué otro nombre se conoce el ciclo del agua?', '¿Qué es lo que transforma la leche en yogur?', '¿En qué lugar del cuerpo se produce la insulina?', '¿Con que parte del cuerpo hacen el zumbido las abejas?', '¿Cuál es la fórmula química del agua?', '¿Cuál es el símbolo de Bromo?', '¿En qué parte del cuerpo se encuentra el tendón de Aquiles?', '¿Qué son los "julios"?', '¿Cuál es el mineral más duro del planeta?', '¿Cuál es la fuente de energía más utilizada en la actualidad?', '¿Qué metal es líquido a temperatura ambiente?', '¿Cómo se denomina la ciencia que estudia la naturaleza,las leyes y distribución de fenómenos meteorológicos?', '¿Cuántos son los dientes de leche?', '¿Qué es la hemofobia?', '¿Cuál es el animal que tiene la presión más alta?', '¿Cómo se llama el movimiento que realiza la Tierra alrededor del Sol?');

	$_SESSION['respuestasCiencia'] = array( array('Hepatitis', 'Diabetes', 'Artrósis', 'Cifoescoliosis'), array('La absorción de nutrientes', 'La digestión mecánica de los alimentos', 'La absorción de agua', 'La digestión química de alimentos'), array('De sólido a líquido', 'De sólido a gaseoso', 'De gaseoso a líquido', 'De líquido a solido'), array('20 caras', '16 caras', '8 caras', '24 caras'), array('Ciclo natural', 'Ciclo hidropónico', 'Ciclo hidrológico', 'Ciclo acuoso'),  array('Un virus', 'Un musgo', 'Una bacteria', 'El tiempo'), array('Páncreas', 'Hígado', 'Intestino', 'Riñon'), array('Con las patas', 'Con las alas', 'Con la boca', 'Con las antenas'), array('HO', 'HO2', 'H2O', 'Agu'), array('No es un elemento,es un compuesto', 'B', 'Br', 'Bh'), array('En el  brazo', 'En el tobillo', 'En la espalda', 'En la rodilla'), array('Magnitud para el calor del sol', 'Magnitud de la energía,trabajo y calor', 'El mes más frío del invierno', 'El mes más caluroso del verano'), array('Adamantio', 'Cuarzo ', 'Diamante', 'Mármol'), array('Petróleo', 'Carbón', 'Biomasa', 'Energía nuclear'), array('Mercurio', 'Hierro', 'Wolframio', 'Niquel'), array('Biología', 'Meteorología', 'Fenomenología', 'Tiempología'), array('10', '15', '20', '25'), array('Miedo a la oscuridad', 'Miedo al agua', 'Miedo a las alturas', 'Miedo a la sangre'), array('Conejo', 'Serpiente', 'Elefante', 'Jirafa'), array('Traslación', 'Rotación', 'La Tierra no se mueve', 'Órbita'));

	//Comprobar si el array de las preguntas está vacío o no.
	if ($_SESSION['vacioCiencias']=='si') {
		$_SESSION['preguntasCiencia']=$preguntasCiencia;
		$_SESSION['vacioCiencias']='no';
	}

	$sala= mt_rand(1,10);
	$_SESSION['sala']=$sala;
	header('Location: sala' . $sala . '.php');

?>