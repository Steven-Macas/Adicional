<?php
	SESSION_START();
?>
<!DOCTYPE html>
<html lang="es">
	<head>
		<title>Ciencias</title>
		<meta charset="UTF-8"/>
		<link rel="stylesheet" type="text/css" href="index.css"/>
      <link rel="icon" href="./imagenes/logo.png"/>
	</head>
	<body>
		<section id="bienvenidoCiencia">
			<div id="parteMedio">
				<h1>Bienvenido al mundo de Laberentix</h1>
				<h2>Te encontrarás con todo tipo de preguntas sobre la ciencia</h2>
				<img src="./imagenes/laberinto3.png" alt="portada" id="portada"/>
				<a href="inicio.php" id="empezar"><h3>A calcular</h3></a>
				<h3>ADVERTENCIA: Una vez que entres, solo hay tres formas de salir, tienes que acertar 10 preguntas o encontrar la puerta de la sala final o tienes que encontrar la puerta escondida que pocos la han encontrado.</h3>
			</div>
		</section>
		<?php
			$_SESSION['vacioCiencias']='si';
			$_SESSION['acertadas']=0;
		?>
	</body>
</html>