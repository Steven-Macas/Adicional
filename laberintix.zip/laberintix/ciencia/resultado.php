<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Resultado</title>
	<link rel="stylesheet" type="text/css" href="index.css"/>
    <link rel="icon" href="./imagenes/logo.png"/>
</head>
<body>


<?php
if (isset($_POST['respuesta'])) {
	$opcion=$_POST['respuesta'];
	switch ($opcion) {
		case $_SESSION['respuestasCiencia'][0][0]: $_SESSION['respuesta']='bien';
			break;
		
		case $_SESSION['respuestasCiencia'][1][2]: $_SESSION['respuesta']='bien';
			break;

		case $_SESSION['respuestasCiencia'][2][1]: $_SESSION['respuesta']='bien';
			break;

		case $_SESSION['respuestasCiencia'][3][0]: $_SESSION['respuesta']='bien';
			break;

		case $_SESSION['respuestasCiencia'][4][2]: $_SESSION['respuesta']='bien';
			break;

		case $_SESSION['respuestasCiencia'][5][2]: $_SESSION['respuesta']='bien';
			break;
		
		case $_SESSION['respuestasCiencia'][6][0]: $_SESSION['respuesta']='bien';
			break;

		case $_SESSION['respuestasCiencia'][7][1]: $_SESSION['respuesta']='bien';
			break;

		case $_SESSION['respuestasCiencia'][8][2]: $_SESSION['respuesta']='bien';
			break;

		case $_SESSION['respuestasCiencia'][9][2]: $_SESSION['respuesta']='bien';
			break;

		case $_SESSION['respuestasCiencia'][10][1]: $_SESSION['respuesta']='bien';
			break;
		
		case $_SESSION['respuestasCiencia'][11][1]: $_SESSION['respuesta']='bien';
			break;

		case $_SESSION['respuestasCiencia'][12][2]: $_SESSION['respuesta']='bien';
			break;

		case $_SESSION['respuestasCiencia'][13][0]: $_SESSION['respuesta']='bien';
			break;

		case $_SESSION['respuestasCiencia'][14][0]: $_SESSION['respuesta']='bien';
			break;

		case $_SESSION['respuestasCiencia'][15][1]: $_SESSION['respuesta']='bien';
			break;
		
		case $_SESSION['respuestasCiencia'][16][2]: $_SESSION['respuesta']='bien';
			break;

		case $_SESSION['respuestasCiencia'][17][3]: $_SESSION['respuesta']='bien';
			break;

		case $_SESSION['respuestasCiencia'][18][3]: $_SESSION['respuesta']='bien';
			break;

		case $_SESSION['respuestasCiencia'][19][0]: $_SESSION['respuesta']='bien';
			break;
		default: $_SESSION['respuesta']="mal";
			break;
	}
	if (isset($_SESSION['jefeFinal'])) {
		if ($_SESSION['jefeFinal']=='si') {
			if ($_SESSION['respuesta']=="bien"){
			echo "<h1>¡Enhorabuena! Acabas de ganar la insignia de Ciencia</h1>";
			echo "<a href='./../categorias.php' id='puertaAbierta'><img src='./imagenes/puertaAbierta.png' alt='Puerta Abierta' id='resultadoJefe'/></a>";
			$_SESSION['PUERTA3']='abierta';
			$_SESSION['INSIGNIA3']='acertado';
			}else{
				echo "<h1>¡Casi...! Has fallado por poco</h1>";
					echo "<h2 id='resultado'>Has perdido todos tus puntos pero sigue intentándolo. ¡Ánimo!";
					echo "<a href='./inicio.php' id='resultado'><h3>Siguiente Sala</h3></a>";
					$_SESSION['acertadas']=0;
					unset($_SESSION['jefeFinal']);
					$_SESSION['totalAcertadas']++;
			}
		}
	}else{
		if ($_SESSION['respuesta']=="bien") {
			unset($_SESSION['preguntasCiencia'][$_SESSION['preguntaCiencia']]);
			$_SESSION['acertadas']++;
			echo "<h1>¡Enhorabuena! Has acertado</h1>";
			if ($_SESSION['acertadas']>=10) {
				echo "<h2 id='resultado'>Tienes 10 puntos. Preparate que detrás de la puerta está la sala final</h2>";
				echo "<a href='jefeCiencias.php'><img src='./imagenes/puertaJefe.png' alt='Puerta Final' id='resultadoJefe'/></a>";
				$_SESSION['totalAcertadas']++;
			}else{
				$faltan=10-$_SESSION['acertadas'];
				echo "<h2 id='resultado'>Tienes " . $_SESSION['acertadas'] . " puntos, te faltan " . $faltan . " puntos más para entrar a la sala final. ¡Ánimo!";
				echo "<a href='./inicio.php' id='resultado'><h3 id='resultado'>Siguiente Sala</h3></a>";
				$_SESSION['totalAcertadas']++;
			}
		}else{
			echo "<h1>¡Casi...! Has fallado por poco</h1>";
			$faltan=10-$_SESSION['acertadas'];
				echo "<h2 id='resultado'>Tienes " . $_SESSION['acertadas'] . " puntos, te faltan " . $faltan . " puntos más para entrar a la sala final. ¡Ánimo!";
				echo "<a href='./inicio.php' id='resultado'><h3 id='resultado'>Siguiente Sala</h3></a>";
		}
	}

	//comprobar si aún quedan preguntas disponibles

	if ($_SESSION['totalAcertadas']==20) {
		$_SESSION['vacioCiencias']='si';
	}
}else{
	$_SESSION['respondida']='no';
	header('Location: sala'. $_SESSION['sala'] . ".php");
}
	
?>
</body>
</html>