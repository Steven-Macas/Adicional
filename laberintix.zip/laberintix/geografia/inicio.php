<?php

	SESSION_START();

	//Array donde se guarda las preguntas
	$preguntasGeografia = array('¿Cuál es el país menos turístico de Europa?', '¿A qué país pertenece la isla de Tasmania?', '¿En cuál de los siguientes países NO hay ningún desierto?', '¿Con cuántos países limita Argentina?', '¿Cuál es la capital de Suiza?', '¿En qué país está la Laguna Verde?', '¿Qué ciudad europea es famosa por la belleza de su parlamento?', '¿A qué país pertenece la isla Mujeres?', '¿En qué mar desemboca el rio Segura?', '¿A qué país pertenece la Isla de Pascua?', '¿En qué país de África es el español el idioma oficial?', '¿Cuál es la capital de Argelia?', '¿En qué continente está la India?', '¿Cúal es la capital de Alemania?', '¿Cuál de estos países no está en una isla?', '¿Dónde queda el monumento a la mitad del mundo?', '¿Dónde se encuentra la ciudad de Bahía Blanca?', '¿Dónde se celebra el Oktoberfest?', '¿Cuándo es verano en el hemisferio sur?', '¿A qué país tienes que ir para visitar el turístico pueblo costero de Sidi Bou Said?');

	$_SESSION['respuestasGeografia'] = array( array('Armenia', 'Moldavia', 'Liechtenstein', 'Hungría'), array('Estados Unidos', 'Australia', 'Portugal', 'Argentina'), array('España', 'Chile', 'Mongolia', 'Alemania'), array('Tres', 'Cuatro', 'Cinco', 'Seis'), array('Berna', 'Zurich', 'Ginebra', 'Basilea'), array('Chile', 'Argentina', 'Bolivia', 'Venezuela'), array('París', 'Madrid', 'Praga', 'Budapest'), array('México', 'Argentina', 'Colombia', 'Chile'), array('Ninguna es correcta', 'Mar Cantábrico', 'Mar Báltico', 'Mar Mediterráneo'), array('Indonesia', 'Chile', 'Australia', 'México'), array('Camerún', 'Gabón', 'Ghana', 'Guinea Ecuatorial'), array('Argela', 'Arabia', 'Colombo', 'Argel'), array('África', 'América', 'Asia', 'Europa'), array('Berlín', 'Múnich', 'Frankfurt', 'Dublin'), array('Japón', 'Jamaica', 'Madagascar', 'Ghana'), array('Quito', 'Bogota', 'Lima', 'Manaos'), array('Uruguay', 'Argentina', 'Chile', 'Brasil'), array('Alemania', 'Rusia', 'Ucrania', 'Reino Unido'), array('De diciembre a marzo', 'De marzo a junio', 'De junio a septiembre', 'De septiembre a diciembre'), array('Marruecos ', 'Egipto', 'Túnez', 'Libia'));

	//Comprobar si el array de las preguntas está vacío o no.
	if ($_SESSION['vacioGeografias']=='si') {
		$_SESSION['preguntasGeografia']=$preguntasGeografia;
		$_SESSION['vacioGeografias']='no';
	}

	$sala= mt_rand(1,10);
	$_SESSION['sala']=$sala;
	header('Location: sala' . $sala . '.php');

?>